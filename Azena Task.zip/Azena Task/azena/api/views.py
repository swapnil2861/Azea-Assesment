from django.db.models.query import QuerySet
from django.http import request
from django.shortcuts import render
from django.views import View
from .models import Post
# Create your views here.

# class based view 
class Post_view(View):
    def get(self, request):
        # python QuerySet to get products
        data = Post.objects.all()
        
        # converting QuerySet to python data/dict using serializers
        # serializers = PostSerializers(data, many=True)

        # sending data into JSON type
        # return JsonResponse(serializers.data, safe=False)
        return render(request , 'index.html', {'data' : data})
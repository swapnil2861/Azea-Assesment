from django.db.models.query import QuerySet
from django.http.response import JsonResponse
from django.views import View
from .models import Post
from .serializers import PostSerializers
# Create your views here.

# class based view 
class Post_view(View):
    def get(self, reques):
        # python QuerySet to get products
        data = Post.objects.all()
        
        # converting QuerySet to python data/dict using serializers
        serializers = PostSerializers(data, many=True)

        # sending data into JSON type
        return JsonResponse(serializers.data, safe=False)
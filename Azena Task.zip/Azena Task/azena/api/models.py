from django.db import models
from django.db.models.deletion import CASCADE
from django.db.models.fields.related import ForeignKey

# Create your models here.
class Catagory(models.Model):
    catagory = models.CharField(max_length=50)

    def __str__(self):
        return self.catagory
    

class Post(models.Model):
    timestamp = models.DateTimeField(auto_now=True)
    uploader_id = models.CharField(max_length=50)
    file = models.FileField (upload_to='upload')
    catagory = models.ForeignKey(Catagory, default=1, on_delete=CASCADE)



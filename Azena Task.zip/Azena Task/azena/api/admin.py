from django.contrib import admin 
from .models import Catagory, Post

# Register your models here.
@admin.register(Post)
class Post_admin(admin.ModelAdmin):
    list_display = [ 'id', 'timestamp', 'uploader_id', 'file', 'catagory']

@admin.register(Catagory)
class Catagory_admin(admin.ModelAdmin):
    list_display = [ 'id', 'catagory']   

# admin.site.register(Catagory)
# admin.site.register(Post)
